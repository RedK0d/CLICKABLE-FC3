
local  aircraft = get_aircraft_type()

if      aircraft=="Su-27" then
    shape_name		   = "Cockpit_SU-27"
elseif  aircraft=="J-11A"                       then
    shape_name		   = "Cockpit_J-11A"
elseif  aircraft=="Su-33"                       then
    shape_name		   = "Cockpit_SU-33"
elseif  aircraft=="Su-25T"                       then
    shape_name		   = "Cockpit_SU-25T"
elseif  aircraft=="Su-25"                       then
    shape_name		   = "Cockpit_SU-25"
elseif  aircraft=="MiG-29A"                       then
    shape_name		   = "Cockpit_MiG-29a"
elseif  aircraft=="MiG-29G"                       then
    shape_name		   = "Cockpit_MiG-29g"   
elseif  aircraft=="MiG-29S"                       then
    shape_name		   = "Cockpit_MiG-29s"  
end






need_to_be_closed = false