dofile(lfs.writedir().."Config\\options.lua")
local  aircraft = get_aircraft_type()
local livree =  {
                    ["FC3"] =   {
                                    ["CPLocalList_A-10A"]   = options.plugins.FC3["CPLocalList_A-10A"],
                                    ["CPLocalList_F-15C"]   = options.plugins.FC3["CPLocalList_F-15C"],
                                    ["CPLocalList_J-11A"]   = options.plugins.FC3["CPLocalList_J-11A"],
                                    ["CPLocalList_MiG-29A"] = options.plugins.FC3["CPLocalList_MiG-29A"],
                                    ["CPLocalList_MiG-29G"] = options.plugins.FC3["CPLocalList_MiG-29G"],
                                    ["CPLocalList_MiG-29S"] = options.plugins.FC3["CPLocalList_MiG-29S"],
                                    ["CPLocalList_Su-25"]   = options.plugins.FC3["CPLocalList_Su-25"],
                                    ["CPLocalList_Su-27"]   = options.plugins.FC3["CPLocalList_Su-27"],
                                    ["CPLocalList_Su-33"]   = options.plugins.FC3["CPLocalList_Su-33"],
                                }
                }

if      aircraft=="Su-27" then
    shape_name		   = "Cockpit_SU-27"
    livery             = livree.FC3["CPLocalList_Su-27"]  
elseif  aircraft=="J-11A"                       then
    shape_name		   = "Cockpit_J-11A"
    livery             = livree.FC3["CPLocalList_J-11A"]  
elseif  aircraft=="Su-33"                       then
    shape_name		   = "Cockpit_SU-33"
    livery             = livree.FC3["CPLocalList_Su-33"] 
elseif  aircraft=="MiG-29A"                       then
    shape_name		   = "Cockpit_MiG-29a"
    livery             = livree.FC3["CPLocalList_MiG-29A"] 
elseif  aircraft=="MiG-29G"                       then
    shape_name		   = "Cockpit_MiG-29g"   
    livery             = livree.FC3["CPLocalList_MiG-29G"] 
elseif  aircraft=="MiG-29S"                       then
    shape_name		   = "Cockpit_MiG-29s"  
    livery             = livree.FC3["CPLocalList_MiG-29S"] 
end






need_to_be_closed = false