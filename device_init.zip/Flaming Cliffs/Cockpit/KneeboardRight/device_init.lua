

attributes = {
	"support_for_cws",
}
MainPanel = {"ccMainPanel",LockOn_Options.script_path.."mainpanel_init.lua", {} }

---------------------------------------------
dofile(LockOn_Options.common_script_path.."KNEEBOARD/declare_kneeboard_device.lua")
---------------------------------------------
