dofile(lfs.writedir().."Config\\options.lua")
local  aircraft = get_aircraft_type()
local livree =  {
                    ["Su-33"] =   {
                                    ["CPLocalList"]         = options.plugins["Su-33"]["CPLocalList"],
                                }
                }

if      aircraft=="Su-33" then
    shape_name		    = "Cockpit_SU-33"
    livery             = livree["Su-33"]["CPLocalList"]
end






need_to_be_closed = false