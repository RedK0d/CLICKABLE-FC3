dofile(lfs.writedir().."Config\\options.lua")
local  aircraft = get_aircraft_type()
local livree =  {
                    ["Su-25T"] =   {
                                    ["CPLocalList"]         = options.plugins["Su-25T"]["CPLocalList"],
                                }
                }

if      aircraft=="Su-25T" then
    shape_name		    = "Cockpit_SU-25T"
    livery             = livree["Su-25T"]["CPLocalList"]
end






need_to_be_closed = false