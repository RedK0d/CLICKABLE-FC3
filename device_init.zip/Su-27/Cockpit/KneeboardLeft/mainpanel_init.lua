dofile(lfs.writedir().."Config\\options.lua")
local  aircraft = get_aircraft_type()
local livree =  {
                    ["Su-27"] =   {
                                    ["CPLocalList"]         = options.plugins["Su-27"]["CPLocalList"],
                                }
                }

if      aircraft=="Su-27" then
    shape_name		    = "Cockpit_SU-27"
    livery             = livree["Su-27"]["CPLocalList"]
end






need_to_be_closed = false