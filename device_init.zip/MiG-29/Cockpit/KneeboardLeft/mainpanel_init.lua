dofile(lfs.writedir().."Config\\options.lua")
local  aircraft = get_aircraft_type()
local livree =  {
                    ["MiG-29"] =   {
                                    ["CPLocalList"]         = options.plugins["Mig-29"]["CPLocalList"],
                                }
                }

if      aircraft=="MiG-29A" then
    shape_name		    = "Cockpit_MiG-29a"
    livery             = livree["MiG-29"]["CPLocalList"]
end
if      aircraft=="MiG-29G" then
    shape_name		    = "Cockpit_MiG-29g"
    livery             = livree["MiG-29"]["CPLocalList"]
end
if      aircraft=="MiG-29S" then
    shape_name		    = "Cockpit_MiG-29s"
    livery             = livree["MiG-29"]["CPLocalList"]
end






need_to_be_closed = false